# Assortment Advisor: AI-Powered Category Management

LLM + Analytics assortment planning project for retail category management. The app combines:

- Instacart product/order data for SKU demand, reorder behavior, and trend signals.
- Rossmann store sales data converted into synthetic analytical regional profiles.
- Deterministically simulated supplier availability data for fill rate, lead time, stock cover, and replenishment risk.
- A local K-Means ML model for add, retain, and remove recommendation actions.
- A local Ollama/Llama advisor panel that turns analytics facts into category-manager briefs.

## Deliverable

Open `index.html` to view the dashboard. It includes:

- Add, remove, and retain assortment recommendations.
- Fast-moving and slow-moving SKU identification.
- Region-specific category suggestions.
- Supplier-aware replenishment insights.
- Explainable recommendation text for category managers.
- Model cluster, model score, and normalized cluster-proximity score for each recommendation.
- K-Means validation metrics and a K=3 to K=9 comparison table.
- Local LLM brief generation using Ollama/Llama with no paid API key.
- A Research Gap Addressed panel that connects the implementation to the literature gap.

## Research Gap Addressed

The 20-paper review shows that existing grocery recommendation, retail analytics, clustering, LLM, and dashboard systems often solve separate parts of the category-management problem. Many works focus on customer-facing product recommendation, search ranking, mathematical assortment optimization, clustering validation, or natural-language generation. Fewer works combine these into one reproducible dashboard for category managers.

This project addresses that gap by combining:

- Sales trends from POS-style basket data.
- Synthetic local preference profiles derived from store sales signals.
- Simulated supplier feasibility through fill rate, lead time, stock cover, and risk status.
- Unsupervised K-Means assortment segmentation.
- Internal clustering validation with inertia, silhouette, Davies-Bouldin, and Calinski-Harabasz metrics.
- Cluster-to-action mapping for `ADD`, `RETAIN`, and `REMOVE`.
- A local Ollama/Llama advisor that explains filtered analytics facts without a paid API.

## Citation Basis

The dashboard uses the same citation structure as the IEEE-style research paper:

- `[1]-[5]`: assortment optimization and category management.
- `[6]-[10]`: grocery recommendation, retail analytics, and recommender systems.
- `[11]-[14]`: K-Means clustering and internal validation metrics.
- `[15]-[16]`: business intelligence and visualization-based decision support.
- `[17]-[20]`: transformers, retrieval grounding, and instruction-following LLMs.

## Run In VS Code

1. Open this folder in VS Code.
2. Install dependencies if needed:

   ```bash
   pip install -r requirements.txt
   ```

3. Optional for live LLM output: install Ollama, then run:

   ```bash
   ollama pull llama3.1
   ollama serve
   ```

4. Run the VS Code task **Build analytics data**.
5. Run the VS Code task **Start local dashboard server**.
6. Open `http://127.0.0.1:8000/index.html` or run the VS Code task **Open dashboard**.
7. In the dashboard, use **Generate LLM Brief** in the Local LLM Advisor panel.

The generated dashboard data is already included in `assets/dashboard_data.js` after running the pipeline.
If Ollama is not running, the LLM panel shows an analytics fallback so the dashboard still works offline.
On CPU, local Llama generation may take around 30-90 seconds.

## Data Inputs

The project uses the two supplied archives:

- Instacart Market Basket Analysis archive: products, aisles, departments, prior orders, train orders.
- Rossmann Store Sales archive: store metadata and sales history.

If you rerun the project on another machine, place both zip files in `data/raw/` or run:

```bash
python src/prepare_data.py --source-dir "path/to/folder/with/zips"
```

## Method

The Python pipeline computes demand velocity, reorder rate, add-to-cart priority, and train-vs-prior trend index from POS-style basket data. Rossmann store sales are converted into five synthetic analytical profiles to estimate local preference, traffic, promotion sensitivity, basket value, and recent growth.

Supplier availability is generated deterministically from product/category signals to simulate supplier lists with fill rate, lead time, stock cover, and minimum order quantity. Supplier-risk outputs should be interpreted as simulation results, not real supplier performance. The final `ADD`, `RETAIN`, and `REMOVE` actions are produced by `NVIDIAAssortmentClusterModel`, a local NumPy K-Means model trained on demand, trend, regional fit, supplier, stock, and reorder features. It does not use row-by-row rule thresholds for the recommendation action.

Because K-Means is unsupervised, action labels are assigned after clustering. Clusters are ranked by a composite business-value score, then high-value clusters map to `ADD`, low-value clusters map to `REMOVE`, and middle clusters map to `RETAIN`. The project also reports internal clustering metrics: inertia, sampled silhouette score, Davies-Bouldin index, Calinski-Harabasz score, and a K=3 to K=9 comparison.

The Local LLM Advisor panel sends the current filtered analytics context to Ollama at `http://127.0.0.1:11434/api/generate`. The prompt includes only structured project facts: selected filters, action counts, synthetic profile signals, top add/remove recommendations, supplier risks, clustering validation, and cluster-proximity scores. The LLM writes a category-manager brief from those facts. The LLM is an explanation layer, not the recommendation engine; if Ollama is unavailable, the dashboard uses an analytics fallback.

The analytics model runs on CPU by default so it works in VS Code without cloud APIs or paid services. The feature matrix is GPU-compatible and can be migrated to RAPIDS cuML K-Means in a future NVIDIA-accelerated version.

## Main Files

- `src/prepare_data.py`: builds processed datasets and dashboard payload.
- `src/advisor_engine.py`: ML action model, supplier simulation, and explanation generation.
- `index.html`: offline dashboard.
- `assets/app.js`: dashboard interactions and local Ollama/Llama advisor.
- `data/processed/`: CSV and JSON analytics outputs.
- `data/processed/model_summary.json`: trained model metadata and cluster summary.
- `docs/requirements_traceability.md`: problem-statement checklist.
- `docs/local_llm_setup.md`: local Ollama/Llama setup.
- `docs/model_card.md`: model design and limitations.
