const dataset = window.ASSORTMENT_DATA;

const state = {
  region: "All",
  department: "All",
  action: "All",
  search: "",
  rows: 50,
};

const formatNumber = new Intl.NumberFormat("en-IN");
const formatPercent = new Intl.NumberFormat("en-IN", {
  style: "percent",
  maximumFractionDigits: 0,
});
const formatDecimal = new Intl.NumberFormat("en-IN", {
  maximumFractionDigits: 4,
});

function byId(id) {
  return document.getElementById(id);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function score(value) {
  return `${Math.round(Number(value || 0) * 100)}`;
}

function uniqueSorted(values) {
  return [...new Set(values.filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

function optionList(select, values) {
  select.innerHTML = "";
  values.forEach((value) => {
    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    select.appendChild(option);
  });
}

function chip(value) {
  return `<span class="chip ${String(value).replace(/\s+/g, "-")}">${value}</span>`;
}

function metric(label, value) {
  return `<div class="metric"><span>${label}</span><strong>${value}</strong></div>`;
}

function renderMetrics() {
  const k = dataset.kpis;
  const model = dataset.model || {};
  byId("metrics").innerHTML = [
    metric("Products", formatNumber.format(k.products_analyzed)),
    metric("Synthetic Profiles", formatNumber.format(k.regions)),
    metric("Departments", formatNumber.format(k.departments)),
    metric("ML Clusters", formatNumber.format(k.model_clusters || model.clusters || 0)),
    metric("Cluster Proximity", formatPercent.format(k.avg_cluster_proximity_score || model.average_cluster_proximity_score || 0)),
    metric("Add", formatNumber.format(k.add_recommendations)),
    metric("Remove", formatNumber.format(k.remove_recommendations)),
    metric("Supplier Risk", formatNumber.format(k.supplier_risk_skus)),
  ].join("");
}

function renderModelValidation() {
  const model = dataset.model || {};
  const metrics = model.validation_metrics || {};
  const selectedK = (model.k_selection || []).find((row) => row.selected) || {};
  const kRows = (model.k_selection || [])
    .map(
      (row) => `
        <tr class="${row.selected ? "selected-k" : ""}">
          <td>${row.k}</td>
          <td>${formatDecimal.format(row.silhouette_score_sample ?? 0)}</td>
          <td>${formatDecimal.format(row.davies_bouldin_index ?? 0)}</td>
          <td>${formatNumber.format(Math.round(row.calinski_harabasz_score ?? 0))}</td>
          <td>${formatDecimal.format(row.selection_score ?? 0)}</td>
        </tr>
      `,
    )
    .join("");

  byId("modelValidation").innerHTML = `
    <div class="validation-summary">
      <div><span>Selected K</span><strong>${model.clusters || selectedK.k || "-"}</strong></div>
      <div><span>Silhouette sample</span><strong>${formatDecimal.format(metrics.silhouette_score_sample ?? 0)}</strong></div>
      <div><span>Davies-Bouldin</span><strong>${formatDecimal.format(metrics.davies_bouldin_index ?? 0)}</strong></div>
      <div><span>Calinski-Harabasz</span><strong>${formatNumber.format(Math.round(metrics.calinski_harabasz_score ?? 0))}</strong></div>
      <div><span>Avg. cluster proximity</span><strong>${formatPercent.format(model.average_cluster_proximity_score || 0)}</strong></div>
    </div>
    <p class="model-note">${escapeHtml(model.cluster_proximity_note || "")}</p>
    <p class="model-note">${escapeHtml(model.action_mapping_method || "")}</p>
    <p class="model-note">${escapeHtml(model.k_selection_note || "")}</p>
    <div class="k-table-wrap">
      <table class="k-table">
        <thead>
          <tr>
            <th>K</th>
            <th>Silhouette</th>
            <th>DBI</th>
            <th>CH</th>
            <th>Selection</th>
          </tr>
        </thead>
        <tbody>${kRows}</tbody>
      </table>
    </div>
  `;
}

function filteredRecords() {
  const search = state.search.trim().toLowerCase();
  return dataset.records.filter((row) => {
    const regionOk = state.region === "All" || row.region === state.region;
    const departmentOk = state.department === "All" || row.department === state.department;
    const actionOk = state.action === "All" || row.action === state.action;
    const searchOk =
      !search ||
      row.product_name.toLowerCase().includes(search) ||
      row.aisle.toLowerCase().includes(search) ||
      row.department.toLowerCase().includes(search);
    return regionOk && departmentOk && actionOk && searchOk;
  });
}

function renderBarChart(target, rows, classMap = {}) {
  const max = Math.max(...rows.map((row) => row.value), 1);
  target.innerHTML = rows
    .map((row) => {
      const width = Math.max(3, (row.value / max) * 100);
      const fillClass = classMap[row.label] || "fill-retain";
      return `
        <div class="bar-row">
          <span>${row.label}</span>
          <div class="bar-track"><div class="bar-fill ${fillClass}" style="width:${width}%"></div></div>
          <strong>${formatNumber.format(row.value)}</strong>
        </div>
      `;
    })
    .join("");
}

function renderCharts(records) {
  const actions = ["ADD", "RETAIN", "REMOVE"].map((label) => ({
    label,
    value: records.filter((row) => row.action === label).length,
  }));
  renderBarChart(byId("actionChart"), actions, {
    ADD: "fill-add",
    RETAIN: "fill-retain",
    REMOVE: "fill-remove",
  });

  const movements = ["Fast-moving", "Steady", "Slow-moving"].map((label) => ({
    label,
    value: records.filter((row) => row.movement_class === label).length,
  }));
  renderBarChart(byId("movementChart"), movements, {
    "Fast-moving": "fill-add",
    Steady: "fill-steady",
    "Slow-moving": "fill-remove",
  });
}

function renderRegionSignals() {
  const regions = state.region === "All" ? dataset.regions : dataset.regions.filter((row) => row.region === state.region);
  byId("regionSignalLabel").textContent = state.region;
  byId("regionSignals").innerHTML = regions
    .map(
      (row) => `
        <div class="signal-row">
          <div class="signal-name">${row.region}</div>
          <div class="signal-meta">
            Sales ${formatNumber.format(Math.round(row.avg_daily_sales))} ·
            Customers ${formatNumber.format(Math.round(row.avg_customers))} ·
            Promo ${formatPercent.format(row.promo_lift)}
          </div>
          <span class="score">${score(row.region_strength)}</span>
        </div>
      `,
    )
    .join("");
}

function renderCategoryChanges() {
  let rows = dataset.categorySummary;
  if (state.region !== "All") rows = rows.filter((row) => row.region === state.region);
  if (state.department !== "All") rows = rows.filter((row) => row.department === state.department);
  rows = rows.slice(0, 10);
  byId("categoryLabel").textContent = `${rows.length} shown`;
  byId("categoryChanges").innerHTML =
    rows
      .map(
        (row) => `
          <div class="category-row">
            <div class="category-name">${row.department}</div>
            <div class="category-meta">
              ${row.region} · Add ${formatNumber.format(row.add_count)} · Remove ${formatNumber.format(row.remove_count)} · Fast ${formatNumber.format(row.fast_movers)}
            </div>
            ${chip(row.category_change)}
          </div>
        `,
      )
      .join("") || `<div class="muted">No matching categories.</div>`;
}

function currentBrief() {
  if (state.region !== "All") {
    return dataset.advisorBriefs.find((brief) => brief.region === state.region) || dataset.advisorBriefs[0];
  }
  const strongest = [...dataset.regions].sort((a, b) => b.region_strength - a.region_strength)[0];
  return dataset.advisorBriefs.find((brief) => brief.region === strongest.region) || dataset.advisorBriefs[0];
}

function renderBrief() {
  const brief = currentBrief();
  byId("briefRegion").textContent = brief.region;
  byId("advisorBrief").textContent = brief.brief;
}

function countBy(rows, key, labels = []) {
  const counts = Object.fromEntries(labels.map((label) => [label, 0]));
  rows.forEach((row) => {
    counts[row[key]] = (counts[row[key]] || 0) + 1;
  });
  return counts;
}

function topProducts(rows, mode) {
  const sorted = [...rows];
  if (mode === "ADD") {
    sorted.sort((a, b) => Number(b.assortment_score) - Number(a.assortment_score));
  } else if (mode === "REMOVE") {
    sorted.sort((a, b) => Number(a.assortment_score) - Number(b.assortment_score));
  } else {
    sorted.sort((a, b) => Number(b.demand_score) - Number(a.demand_score));
  }

  return sorted.slice(0, 3).map((row) => ({
    product: row.product_name,
    region: row.region,
    department: row.department,
    action: row.action,
    movement: row.movement_class,
    score: score(row.assortment_score),
    clusterProximity: formatPercent.format(row.cluster_proximity_score || 0),
    supplier: row.supplier_name,
    supplierStatus: row.supplier_status,
    stockCoverDays: Number(row.stock_cover_days).toFixed(1),
  }));
}

function topDepartments(rows) {
  const groups = new Map();
  rows.forEach((row) => {
    const key = row.department || "Unknown";
    const group = groups.get(key) || { department: key, rows: 0, add: 0, retain: 0, remove: 0, scoreTotal: 0 };
    group.rows += 1;
    group.add += row.action === "ADD" ? 1 : 0;
    group.retain += row.action === "RETAIN" ? 1 : 0;
    group.remove += row.action === "REMOVE" ? 1 : 0;
    group.scoreTotal += Number(row.assortment_score || 0);
    groups.set(key, group);
  });

  return [...groups.values()]
    .map((group) => ({
      department: group.department,
      rows: group.rows,
      add: group.add,
      retain: group.retain,
      remove: group.remove,
      averageScore: score(group.scoreTotal / Math.max(group.rows, 1)),
    }))
    .sort((a, b) => b.add + b.remove - (a.add + a.remove))
    .slice(0, 3);
}

function buildAnalyticsContext(records) {
  const actionCounts = countBy(records, "action", ["ADD", "RETAIN", "REMOVE"]);
  const movementCounts = countBy(records, "movement_class", ["Fast-moving", "Steady", "Slow-moving"]);
  const supplierCounts = countBy(records, "supplier_status", ["Ready", "Watch", "Risk"]);
  const filteredRegions = state.region === "All" ? dataset.regions : dataset.regions.filter((row) => row.region === state.region);
  const addRows = records.filter((row) => row.action === "ADD");
  const removeRows = records.filter((row) => row.action === "REMOVE");
  const supplierRiskRows = records.filter((row) => row.supplier_status === "Risk");

  return {
    project: dataset.project.title,
    model: {
      name: dataset.model?.model_name,
      family: dataset.model?.model_family,
      clusters: dataset.model?.clusters,
      averageClusterProximity: dataset.model?.average_cluster_proximity_score,
      validationMetrics: dataset.model?.validation_metrics,
      ruleBasedActions: dataset.model?.uses_rule_based_action_logic,
    },
    filters: {
      region: state.region,
      department: state.department,
      action: state.action,
      search: state.search || "None",
    },
    visibleRecommendationRows: records.length,
    actionCounts,
    movementCounts,
    supplierCounts,
    regionSignals: filteredRegions.map((row) => ({
      region: row.region,
      profileType: row.profile_type,
      avgDailySales: Math.round(row.avg_daily_sales),
      avgCustomers: Math.round(row.avg_customers),
      promoLift: formatPercent.format(row.promo_lift),
      regionStrength: score(row.region_strength),
    })),
    topDepartments: topDepartments(records),
    topAddRecommendations: topProducts(addRows, "ADD"),
    topRemoveRecommendations: topProducts(removeRows, "REMOVE"),
    topSupplierRisks: topProducts(supplierRiskRows, "SUPPLIER"),
  };
}

function renderLLMFacts(records) {
  const context = buildAnalyticsContext(records);
  byId("llmFacts").innerHTML = [
    `<span>Rows ${formatNumber.format(context.visibleRecommendationRows)}</span>`,
    `<span>Add ${formatNumber.format(context.actionCounts.ADD || 0)}</span>`,
    `<span>Remove ${formatNumber.format(context.actionCounts.REMOVE || 0)}</span>`,
    `<span>Supplier Risk ${formatNumber.format(context.supplierCounts.Risk || 0)}</span>`,
    `<span>Cluster Proximity ${formatPercent.format(dataset.model?.average_cluster_proximity_score || 0)}</span>`,
  ].join("");
}

function localAnalyticsBrief(context) {
  const add = context.topAddRecommendations[0];
  const remove = context.topRemoveRecommendations[0];
  const supplier = context.topSupplierRisks[0];
  const category = context.topDepartments[0];
  const region = context.filters.region === "All" ? "all selected regions" : context.filters.region;

  const lines = [
    `Analytics fallback for ${region}: ${formatNumber.format(context.visibleRecommendationRows)} filtered recommendation rows are available, with ${formatNumber.format(context.actionCounts.ADD || 0)} add actions, ${formatNumber.format(context.actionCounts.REMOVE || 0)} remove actions, and ${formatNumber.format(context.supplierCounts.Risk || 0)} supplier-risk rows.`,
  ];

  if (category) {
    lines.push(`Category focus: ${category.department} has ${category.add} add actions, ${category.remove} remove actions, and an average ML score of ${category.averageScore}/100.`);
  }
  if (add) {
    lines.push(`Expansion candidate: ${add.product} in ${add.region} has a ${add.score}/100 ML score and ${add.clusterProximity} cluster proximity.`);
  }
  if (remove) {
    lines.push(`Rationalization candidate: ${remove.product} in ${remove.region} is in the remove segment with a ${remove.score}/100 ML score.`);
  }
  if (supplier) {
    lines.push(`Supplier watch: ${supplier.product} has ${supplier.supplierStatus.toLowerCase()} supplier status with ${supplier.stockCoverDays} days of cover.`);
  }
  lines.push("Next step: review the top add/remove SKUs and confirm supplier feasibility before changing the live assortment.");
  return lines.join("\n\n");
}

function compactPromptFacts(context) {
  const add = context.topAddRecommendations[0];
  const remove = context.topRemoveRecommendations[0];
  const supplier = context.topSupplierRisks[0];
  const category = context.topDepartments[0];
  const regionSignals = context.regionSignals
    .slice(0, 3)
    .map((row) => `${row.region} synthetic profile: sales ${row.avgDailySales}, customers ${row.avgCustomers}, promo ${row.promoLift}, strength ${row.regionStrength}/100`)
    .join("; ");
  const validation = context.model.validationMetrics || {};

  return [
    `Project: ${context.project}`,
    `Filters: synthetic profile ${context.filters.region}, department ${context.filters.department}, action ${context.filters.action}, search ${context.filters.search}`,
    `Model: ${context.model.name}, ${context.model.clusters} clusters, average cluster proximity ${formatPercent.format(context.model.averageClusterProximity || 0)}, ML action mapping enabled`,
    `Validation: silhouette ${formatDecimal.format(validation.silhouette_score_sample || 0)}, Davies-Bouldin ${formatDecimal.format(validation.davies_bouldin_index || 0)}, Calinski-Harabasz ${formatNumber.format(Math.round(validation.calinski_harabasz_score || 0))}`,
    `Rows: ${context.visibleRecommendationRows}`,
    `Actions: ADD ${context.actionCounts.ADD || 0}, RETAIN ${context.actionCounts.RETAIN || 0}, REMOVE ${context.actionCounts.REMOVE || 0}`,
    `Movement: fast ${context.movementCounts["Fast-moving"] || 0}, steady ${context.movementCounts.Steady || 0}, slow ${context.movementCounts["Slow-moving"] || 0}`,
    `Supplier status: ready ${context.supplierCounts.Ready || 0}, watch ${context.supplierCounts.Watch || 0}, risk ${context.supplierCounts.Risk || 0}`,
    `Region signals: ${regionSignals || "No matching region signal"}`,
    category ? `Top category: ${category.department}, rows ${category.rows}, add ${category.add}, remove ${category.remove}, average ML score ${category.averageScore}/100` : "Top category: none",
    add ? `Top add: ${add.product}, ${add.region}, ${add.department}, ML score ${add.score}/100, cluster proximity ${add.clusterProximity}, supplier ${add.supplierStatus}` : "Top add: none",
    remove ? `Top remove: ${remove.product}, ${remove.region}, ${remove.department}, ML score ${remove.score}/100, supplier ${remove.supplierStatus}` : "Top remove: none",
    supplier ? `Top supplier risk: ${supplier.product}, ${supplier.region}, ${supplier.department}, supplier ${supplier.supplier}, stock cover ${supplier.stockCoverDays} days` : "Top supplier risk: none",
  ].join("\n");
}

function buildLLMPrompt(context, focus) {
  const focusText = {
    category: "Write a category-manager action brief.",
    supplier: "Write a supplier-risk and replenishment brief.",
    executive: "Write an executive summary for retail leadership.",
  }[focus];

  return `You are a retail category management assistant for an LLM + Analytics assortment advisor.

Use only the structured analytics facts below. Do not invent products, regions, suppliers, counts, or external market facts.

Task: ${focusText}

Return:
- 3 concise bullets
- one recommended next action
- plain business language
- maximum 90 words

Analytics facts:
${compactPromptFacts(context)}`;
}

async function askLocalLLM(prompt, model) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 120000);
  try {
    const response = await fetch("http://127.0.0.1:11434/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        prompt,
        stream: false,
        options: {
          temperature: 0.2,
          num_predict: 110,
        },
      }),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`Ollama returned ${response.status}`);
    }

    const payload = await response.json();
    if (!payload.response) {
      throw new Error("Ollama returned an empty response");
    }
    return payload.response.trim();
  } finally {
    window.clearTimeout(timeout);
  }
}

async function generateLLMBrief() {
  const button = byId("llmButton");
  const output = byId("llmOutput");
  const status = byId("llmStatus");
  const model = byId("llmModel").value.trim() || "llama3.1";
  const focus = byId("llmFocus").value;
  const context = buildAnalyticsContext(filteredRecords());
  const prompt = buildLLMPrompt(context, focus);

  button.disabled = true;
  status.textContent = `Generating with ${model}`;
  output.textContent = "";

  try {
    output.textContent = await askLocalLLM(prompt, model);
    status.textContent = `Local LLM: ${model}`;
  } catch (error) {
    output.textContent = localAnalyticsBrief(context);
    status.textContent = "Analytics fallback";
  } finally {
    button.disabled = false;
  }
}

function renderMiniTable(targetId, rows, mode) {
  byId(targetId).innerHTML =
    rows
      .slice(0, 8)
      .map((row) => {
        const title = row.product_name || row.department;
        let meta = `${row.region} · ${row.department || ""}`;
        let right = row.action ? chip(row.action) : "";
        if (mode === "supplier") {
          meta = `${row.supplier_name} · ${formatPercent.format(row.fill_rate)} · ${row.lead_time_days} days`;
          right = `<span class="score">${score(row.demand_score)}</span>`;
        } else if (mode === "fast" || mode === "slow") {
          meta = `${row.region} · ${row.department} · Units ${formatNumber.format(Math.round(row.units_total))}`;
        }
        return `
          <div class="mini-row">
            <div class="mini-title">${title}</div>
            <div class="mini-meta">${meta}</div>
            ${right}
          </div>
        `;
      })
      .join("");
}

function renderSideLists() {
  const regionFilter = (row) => state.region === "All" || row.region === state.region;
  renderMiniTable("fastMovers", dataset.fastMovers.filter(regionFilter), "fast");
  renderMiniTable("slowMovers", dataset.slowMovers.filter(regionFilter), "slow");
  renderMiniTable("supplierRisks", dataset.supplierRisks.filter(regionFilter), "supplier");
}

function renderTable(records) {
  const rows = records.slice(0, state.rows);
  byId("tableSummary").textContent = `${formatNumber.format(records.length)} matched`;
  byId("recommendationRows").innerHTML =
    rows
      .map(
        (row) => `
          <tr>
            <td>${chip(row.action)}</td>
            <td class="product-cell">${row.product_name}<div class="muted">${row.aisle}</div></td>
            <td>${row.region}</td>
            <td>${row.department}<div>${chip(row.movement_class)}</div></td>
            <td class="score">${score(row.assortment_score)}<div class="muted">Cluster ${row.model_cluster} · ${formatPercent.format(row.cluster_proximity_score || 0)} proximity</div></td>
            <td>${Number(row.trend_index).toFixed(2)}<div class="muted">Reorder ${formatPercent.format(row.reorder_rate)}</div></td>
            <td>${chip(row.supplier_status)}<div class="muted">${row.supplier_name}</div></td>
            <td>${row.replenishment_priority}<div class="muted">${Number(row.stock_cover_days).toFixed(1)} days cover</div></td>
            <td class="explain-cell">${row.explanation}</td>
          </tr>
        `,
      )
      .join("");
}

function renderAll() {
  const records = filteredRecords();
  byId("visibleCount").textContent = `${formatNumber.format(records.length)} visible`;
  renderCharts(records);
  renderRegionSignals();
  renderCategoryChanges();
  renderBrief();
  renderLLMFacts(records);
  renderSideLists();
  renderTable(records);
}

function setupFilters() {
  optionList(byId("regionFilter"), ["All", ...dataset.regions.map((row) => row.region)]);
  optionList(byId("departmentFilter"), ["All", ...uniqueSorted(dataset.records.map((row) => row.department))]);

  byId("regionFilter").addEventListener("change", (event) => {
    state.region = event.target.value;
    renderAll();
  });
  byId("departmentFilter").addEventListener("change", (event) => {
    state.department = event.target.value;
    renderAll();
  });
  byId("actionFilter").addEventListener("change", (event) => {
    state.action = event.target.value;
    renderAll();
  });
  byId("searchFilter").addEventListener("input", (event) => {
    state.search = event.target.value;
    renderAll();
  });
  byId("rowLimit").addEventListener("change", (event) => {
    state.rows = Number(event.target.value);
    renderAll();
  });
  byId("llmButton").addEventListener("click", generateLLMBrief);
  byId("resetButton").addEventListener("click", () => {
    state.region = "All";
    state.department = "All";
    state.action = "All";
    state.search = "";
    state.rows = 50;
    byId("regionFilter").value = "All";
    byId("departmentFilter").value = "All";
    byId("actionFilter").value = "All";
    byId("searchFilter").value = "";
    byId("rowLimit").value = "50";
    renderAll();
  });
}

function boot() {
  if (!dataset || !dataset.records) {
    document.body.innerHTML = `
      <main class="shell">
        <section class="panel">
          <h1>Dashboard data is missing</h1>
          <p>Run the data preparation task from VS Code to generate assets/dashboard_data.js.</p>
        </section>
      </main>
    `;
    return;
  }
  renderMetrics();
  renderModelValidation();
  setupFilters();
  renderAll();
  byId("llmOutput").textContent = localAnalyticsBrief(buildAnalyticsContext(filteredRecords()));
}

boot();
