# Model Card: Assortment Advisor

## Model

`NVIDIAAssortmentClusterModel` is a local K-Means clustering model implemented with NumPy. It segments product-region combinations into learned assortment groups and maps those learned clusters to `ADD`, `RETAIN`, and `REMOVE` recommendation actions.

## Why This Model

The supplied public datasets do not contain real category-manager approval labels. Because of that, a supervised classifier would require invented labels. K-Means is used instead because it can learn segments directly from the available demand, local preference, supplier, stock, and reorder features.

K-Means does not directly know the meaning of `ADD`, `RETAIN`, or `REMOVE`. After clustering, clusters are ranked by a composite business-value score:

```text
0.22*demand_score + 0.16*velocity_rank + 0.13*trend_score
+ 0.12*region_fit_score + 0.10*reorder_rate + 0.09*supplier_score
+ 0.07*fill_rate + 0.05*local_preference_score
+ 0.04*lead_time_score + 0.02*stock_cover_score
```

The highest-value clusters are mapped to `ADD`, the lowest-value clusters are mapped to `REMOVE`, and middle clusters are mapped to `RETAIN`.

## Features Used

- Demand score
- Trend score
- Reorder rate
- Add-to-cart priority
- Unit velocity rank
- Region fit score
- Local preference score
- Supplier score
- Fill rate
- Lead time days
- Stock cover days

## Preprocessing and K-Means Settings

The model feature matrix is built from the numeric fields above. Infinite values are replaced with missing values, missing feature values are filled with the column median, and any remaining missing values are filled with `0.0`. The feature matrix is then standardized with z-score scaling. A zero standard deviation is replaced with `1.0` so division by zero does not occur.

The local K-Means implementation uses:

- `random_state = 98`
- `max_iter = 40`
- deterministic centroid initialization from quantiles on a business-axis proxy
- empty-cluster repair by assigning the farthest row to the empty centroid
- K comparison from `K=3` through `K=9`
- `45,000` sampled rows for K comparison
- `1,800` sampled rows for candidate-K silhouette calculations
- `3,000` sampled rows for the final fitted-model silhouette calculation

Table IV in the paper reports candidate-K metrics from the `45,000` row K-selection sample. Table VI reports final fitted-model metrics on all `248,440` product-profile rows, with silhouette estimated from `3,000` sampled rows. Those values are not expected to match exactly because they are different evaluation contexts.

## Outputs

- `action`: ML-generated `ADD`, `RETAIN`, or `REMOVE`
- `assortment_score`: normalized ML cluster score
- `model_cluster`: learned cluster id
- `cluster_proximity_score`: normalized distance-to-centroid score for the assigned cluster
- `action_support_score`: action-support score derived from cluster proximity and cluster value separation

`cluster_proximity_score` is not supervised prediction accuracy and is not a calibrated probability. It only indicates how close a row is to its assigned centroid relative to the cluster distance scale.

## Validation

The generated `model_summary.json` includes internal clustering metrics:

- inertia
- sampled silhouette score
- Davies-Bouldin index
- Calinski-Harabasz score
- K=3 to K=9 comparison table

Because the datasets do not include ground-truth assortment decisions, these are internal clustering metrics rather than recommendation accuracy metrics.

## LLM Advisor Layer

The dashboard includes a Local LLM Advisor panel. It calls Ollama at `http://127.0.0.1:11434/api/generate` and sends the current filtered analytics context to a local Llama model such as `llama3.1`.

The LLM does not create recommendations from scratch. It summarizes structured analytics facts produced by the pipeline: action counts, cluster-proximity scores, synthetic profile signals, top add/remove products, supplier risks, validation metrics, and filtered category context.

## GPU/NVIDIA Fit

The current project runs locally with NumPy so it works in VS Code without an API key. The feature matrix is structured so it can be moved to RAPIDS cuML K-Means on an NVIDIA GPU for faster training on larger retail data. The submitted implementation is CPU-based; GPU acceleration is a compatible future extension.

## Limitations

- Supplier data is synthetically simulated because real supplier availability was not provided.
- Regional profiles are synthetic analytical profiles derived from Rossmann store sales signals, not real geographic regions.
- K-Means is unsupervised, so actions should be reviewed by a category manager before production use.
- The project does not claim supervised recommendation accuracy because no historical human assortment decisions or A/B-test outcomes were provided.
- LLM output requires Ollama to be installed and running locally; otherwise the dashboard uses an analytics fallback.
- Live ERP, inventory, pricing, and promotion data would improve production accuracy.
