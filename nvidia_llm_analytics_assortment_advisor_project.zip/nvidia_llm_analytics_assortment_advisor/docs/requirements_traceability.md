# Requirements Traceability

| Requirement | Implemented In |
| --- | --- |
| Use POS/order data | `src/prepare_data.py` reads Instacart order-product files and computes SKU demand, reorder, cart priority, and trend metrics. |
| Use location/local preference data | `src/prepare_data.py` reads Rossmann sales/store files and builds synthetic analytical regional profiles. |
| Use supplier lists/availability | `src/advisor_engine.py` creates deterministic simulated supplier records with fill rate, lead time, stock cover, MOQ, and status. |
| Suggest category changes | `data/processed/category_summary.csv` and dashboard Category Changes panel. |
| Add/remove/retain recommendations | `NVIDIAAssortmentClusterModel` in `src/advisor_engine.py` trains a K-Means ML model and writes actions to `data/processed/assortment_recommendations.csv` and the dashboard recommendation table. |
| Fast-moving and slow-moving SKU identification | `movement_class` in product metrics and dashboard Fast Movers / Slow Movers panels. |
| Region-specific suggestions | Every recommendation includes a synthetic analytical profile in the `region` field; dashboard filters by profile. |
| Supplier-aware replenishment | `replenishment_priority`, supplier status, fill rate, lead time, and stock cover in CSV/dashboard. |
| Explainable category management recommendations | `explanation` column includes ML cluster, cluster-proximity score, supplier status, score, and action rationale; Advisor Brief panel summarizes profile-level guidance. |
| LLM + Analytics focus | Local LLM Advisor in `assets/app.js` sends filtered analytics facts to Ollama/Llama and writes a grounded category-manager brief. |
| Research gap solution | Dashboard Research Gap Addressed panel and `README.md` show how the project combines sales trends, synthetic local preference, simulated supplier feasibility, unsupervised clustering, validation metrics, ADD/RETAIN/REMOVE mapping, and local LLM explanation in one reproducible workflow. |
| GPU-compatible ML focus | `src/advisor_engine.py` uses a local NumPy K-Means action model, writes clustering validation metrics to `data/processed/model_summary.json`, and keeps a feature matrix that can be moved to RAPIDS cuML for NVIDIA GPU acceleration. |
| Frontend deliverable | `index.html`, `assets/styles.css`, `assets/app.js`. |
| Backend/analytics deliverable | `src/prepare_data.py`, `src/advisor_engine.py`, `data/processed/*.csv`. |
