# Local LLM Setup

This project supports LLM + Analytics without a paid API key by using Ollama locally.

## Install Ollama

Download and install Ollama from:

```text
https://ollama.com/download
```

## Pull A Llama Model

```bash
ollama pull llama3.1
```

## Start Ollama

```bash
ollama serve
```

Ollama usually listens on:

```text
http://127.0.0.1:11434
```

## Use In The Dashboard

Open the dashboard and use the Local LLM Advisor panel. The panel sends the current filtered analytics facts to the local Llama model and generates a category-manager brief.

If Ollama is not running, the dashboard still works and shows an analytics fallback.
On CPU, local Llama generation can take around 30-90 seconds.
