# Research Gap Alignment

## Gap Found From The 20 Papers

The reviewed literature covers important parts of retail intelligence, but mostly in separate streams. Assortment optimization papers focus on demand, substitution, category planning, and omni-channel assortment. Grocery recommendation papers focus on customer-facing product recommendation, next-basket prediction, and search ranking. Clustering papers provide validation methods such as silhouette, Davies-Bouldin, and Calinski-Harabasz, but do not usually translate clusters into category-management actions. LLM papers show strong natural-language generation, but they are not directly grounded in a retail assortment dashboard.

The project gap is therefore:

> Existing systems rarely combine sales trends, local preference, supplier feasibility, unsupervised assortment segmentation, clustering validation, ADD/RETAIN/REMOVE action mapping, and local LLM explanation in one reproducible category-management dashboard.

## How This Project Solves The Gap

| Gap Component | Project Solution |
| --- | --- |
| Sales trend analysis | Instacart order data is used as POS-style basket data to compute demand, reorder, cart priority, and train-vs-prior trend signals. |
| Local preference | Rossmann store sales data is converted into synthetic analytical regional profiles for traffic, basket value, promotion response, growth, and region strength. |
| Supplier feasibility | Supplier availability is simulated with fill rate, lead time, stock cover, MOQ, supplier score, and supplier status. |
| Unsupervised assortment segmentation | K-Means segments product-region rows using demand, trend, region fit, local preference, supplier, fill rate, lead time, and stock-cover features. |
| Action mapping | Clusters are ranked by business value, then mapped to `ADD`, `RETAIN`, and `REMOVE` actions. |
| Model validation | The dashboard reports inertia, sampled silhouette score, Davies-Bouldin index, Calinski-Harabasz score, and K=3 to K=9 comparison. |
| LLM explanation | A local Ollama/Llama panel converts filtered analytics facts into a category-manager brief without a paid API. |
| Reproducibility | The project runs locally in VS Code and stores outputs as CSV, JSON, JavaScript, and dashboard files. |

## Honest Scope

The project solves the research gap at prototype level. It does not claim production-grade retail accuracy because real supplier feeds, live ERP data, shelf capacity, price elasticity, and historical manager approval labels were not provided. Supplier data and regional profiles are clearly marked as synthetic or simulated. The model uses internal clustering metrics instead of supervised accuracy because ground-truth assortment decisions are unavailable.
