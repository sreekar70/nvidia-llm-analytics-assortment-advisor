# Raw Data

Place the supplied zip archives here if you want to rerun the pipeline from inside this project folder:

- `archive (5).zip` with Instacart Market Basket files.
- `archive (7).zip` with Rossmann Store Sales files.

The current build can also discover the archives from the workspace `work/source_files` folder used during project generation.
