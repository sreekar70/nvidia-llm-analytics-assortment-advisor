"""Core recommendation logic for the Assortment Advisor.

The project is intentionally offline-friendly: analytics produce structured
signals, a local ML model assigns assortment actions, and the narrative layer
turns those signals into category-manager recommendations without needing an
external LLM service.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd


REGION_NAMES = {
    0: "North Urban",
    1: "South Value",
    2: "East Family",
    3: "West Convenience",
    4: "Central Promo",
}

MODEL_FEATURES = [
    "demand_score",
    "trend_score",
    "reorder_rate",
    "cart_priority_score",
    "unit_score",
    "velocity_rank",
    "region_fit_score",
    "local_preference_score",
    "supplier_score",
    "fill_rate",
    "lead_time_days",
    "stock_cover_days",
]

FRESH_DEPARTMENTS = {"produce", "dairy eggs", "bakery", "deli", "meat seafood"}
PANTRY_DEPARTMENTS = {
    "snacks",
    "beverages",
    "breakfast",
    "frozen",
    "canned goods",
    "dry goods pasta",
    "international",
    "bulk",
}
CARE_DEPARTMENTS = {"household", "personal care", "babies", "pets", "missing"}


@dataclass(frozen=True)
class SupplierTemplate:
    name: str
    tier: str
    fill_base: float
    lead_base: int


SUPPLIER_TEMPLATES = (
    SupplierTemplate("FreshSource Foods", "Fresh", 0.89, 4),
    SupplierTemplate("Daily Basket Distributors", "Core Grocery", 0.86, 6),
    SupplierTemplate("ValueLine Wholesale", "Value", 0.80, 8),
    SupplierTemplate("Prime Pantry Network", "Premium", 0.92, 5),
    SupplierTemplate("Regional Essentials Co.", "Regional", 0.83, 9),
    SupplierTemplate("LongLead Imports", "Import", 0.76, 13),
)


def stable_fraction(*parts: object) -> float:
    """Return a deterministic pseudo-random fraction for repeatable outputs."""

    token = "|".join(str(part) for part in parts)
    digest = hashlib.sha1(token.encode("utf-8")).hexdigest()[:12]
    return int(digest, 16) / float(16**12 - 1)


def minmax(series: pd.Series, floor: float | None = None, cap: float | None = None) -> pd.Series:
    values = series.astype(float)
    if floor is not None or cap is not None:
        values = values.clip(lower=floor, upper=cap)
    minimum = values.min()
    maximum = values.max()
    if pd.isna(minimum) or pd.isna(maximum) or maximum == minimum:
        return pd.Series(np.full(len(values), 0.5), index=series.index)
    return (values - minimum) / (maximum - minimum)


def department_role(department: str) -> str:
    dep = str(department).lower()
    if dep in FRESH_DEPARTMENTS:
        return "Fresh"
    if dep in PANTRY_DEPARTMENTS:
        return "Pantry"
    if dep in CARE_DEPARTMENTS:
        return "Care"
    return "General"


def assign_region(store_id: int) -> str:
    return REGION_NAMES[int(store_id) % len(REGION_NAMES)]


def movement_label(row: pd.Series) -> str:
    if row["velocity_rank"] >= 0.85 and row["trend_index"] >= 0.92:
        return "Fast-moving"
    if row["velocity_rank"] <= 0.20 or row["trend_index"] <= 0.72:
        return "Slow-moving"
    return "Steady"


class NVIDIAAssortmentClusterModel:
    """Local ML model that segments product-region rows into assortment actions.

    It is implemented with NumPy so the project runs in VS Code without extra
    downloads. The same numeric feature matrix is compatible with RAPIDS cuML
    K-Means if NVIDIA GPU acceleration is added later.
    """

    def __init__(
        self,
        n_clusters: int = 3,
        max_iter: int = 40,
        random_state: int = 98,
        add_share: float = 0.10,
        remove_share: float = 0.25,
    ) -> None:
        self.n_clusters = n_clusters
        self.max_iter = max_iter
        self.random_state = random_state
        self.add_share = add_share
        self.remove_share = remove_share
        self.summary_: dict[str, object] = {}

    def _feature_matrix(self, frame: pd.DataFrame) -> tuple[pd.DataFrame, np.ndarray]:
        features = frame[MODEL_FEATURES].astype(float).replace([np.inf, -np.inf], np.nan)
        features = features.fillna(features.median(numeric_only=True)).fillna(0.0)
        mean = features.mean(axis=0)
        std = features.std(axis=0).replace(0, 1.0)
        matrix = ((features - mean) / std).to_numpy(dtype=float)
        self._mean = mean
        self._std = std
        return features, matrix

    def _business_axis(self, features: pd.DataFrame) -> np.ndarray:
        lead_time_score = 1 - np.clip((features["lead_time_days"] - 2) / 19, 0, 1)
        stock_cover_score = np.clip(features["stock_cover_days"] / 28, 0, 1)
        return (
            0.20 * features["demand_score"]
            + 0.16 * features["velocity_rank"]
            + 0.13 * features["trend_score"]
            + 0.12 * features["region_fit_score"]
            + 0.10 * features["reorder_rate"]
            + 0.09 * features["supplier_score"]
            + 0.07 * features["fill_rate"]
            + 0.06 * features["local_preference_score"]
            + 0.04 * features["cart_priority_score"]
            + 0.02 * lead_time_score
            + 0.01 * stock_cover_score
        ).to_numpy(dtype=float)

    def _initial_centroids(
        self,
        features: pd.DataFrame,
        matrix: np.ndarray,
        n_clusters: int | None = None,
    ) -> np.ndarray:
        n_clusters = int(n_clusters or self.n_clusters)
        axis = self._business_axis(features)
        quantiles = np.linspace(0.04, 0.96, n_clusters)
        centroids: list[np.ndarray] = []
        used: set[int] = set()

        for quantile in quantiles:
            target = float(np.quantile(axis, quantile))
            order = np.argsort(np.abs(axis - target))
            pick = next((int(idx) for idx in order if int(idx) not in used), int(order[0]))
            used.add(pick)
            centroids.append(matrix[pick].copy())

        return np.vstack(centroids)

    def _fit_kmeans(
        self,
        matrix: np.ndarray,
        centroids: np.ndarray,
        n_clusters: int | None = None,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
        n_clusters = int(n_clusters or self.n_clusters)
        labels = np.zeros(len(matrix), dtype=int)
        distances = np.zeros(len(matrix), dtype=float)

        for iteration in range(1, self.max_iter + 1):
            all_distances = ((matrix[:, None, :] - centroids[None, :, :]) ** 2).sum(axis=2)
            labels = all_distances.argmin(axis=1)
            distances = np.sqrt(all_distances[np.arange(len(matrix)), labels])

            updated = centroids.copy()
            for cluster in range(n_clusters):
                mask = labels == cluster
                if mask.any():
                    updated[cluster] = matrix[mask].mean(axis=0)
                else:
                    farthest = int(np.argmax(distances))
                    updated[cluster] = matrix[farthest]

            shift = float(np.linalg.norm(updated - centroids))
            centroids = updated
            if shift < 0.0001:
                break

        return labels, distances, centroids, iteration

    @staticmethod
    def _sample_indices(row_count: int, sample_size: int, random_state: int) -> np.ndarray:
        sample_size = min(int(sample_size), int(row_count))
        if sample_size <= 0:
            return np.array([], dtype=int)
        if sample_size == row_count:
            return np.arange(row_count, dtype=int)
        rng = np.random.default_rng(random_state)
        return np.sort(rng.choice(row_count, size=sample_size, replace=False))

    @staticmethod
    def _silhouette_sample(
        matrix: np.ndarray,
        labels: np.ndarray,
        sample_size: int = 3000,
        random_state: int = 98,
    ) -> tuple[float, int]:
        sample_idx = NVIDIAAssortmentClusterModel._sample_indices(len(matrix), sample_size, random_state)
        if len(sample_idx) < 3:
            return 0.0, int(len(sample_idx))

        sample = matrix[sample_idx]
        sample_labels = labels[sample_idx]
        unique_labels = np.unique(sample_labels)
        if len(unique_labels) < 2:
            return 0.0, int(len(sample_idx))

        masks = {int(label): sample_labels == label for label in unique_labels}
        counts = {label: int(mask.sum()) for label, mask in masks.items()}
        values: list[np.ndarray] = []
        chunk_size = 250

        for start in range(0, len(sample), chunk_size):
            end = min(start + chunk_size, len(sample))
            chunk = sample[start:end]
            distances = np.sqrt(((chunk[:, None, :] - sample[None, :, :]) ** 2).sum(axis=2))
            chunk_scores = np.zeros(end - start, dtype=float)

            for offset, label in enumerate(sample_labels[start:end]):
                label_int = int(label)
                own_mask = masks[label_int]
                own_count = counts[label_int]
                if own_count > 1:
                    a_value = float(distances[offset, own_mask].sum() / (own_count - 1))
                else:
                    a_value = 0.0

                other_means = [
                    float(distances[offset, mask].mean())
                    for other_label, mask in masks.items()
                    if other_label != label_int and mask.any()
                ]
                b_value = min(other_means) if other_means else 0.0
                denominator = max(a_value, b_value)
                chunk_scores[offset] = 0.0 if denominator == 0 else (b_value - a_value) / denominator

            values.append(chunk_scores)

        return round(float(np.concatenate(values).mean()), 4), int(len(sample_idx))

    @staticmethod
    def _validation_metrics(
        matrix: np.ndarray,
        labels: np.ndarray,
        centroids: np.ndarray,
        distances: np.ndarray,
        random_state: int,
        silhouette_sample_size: int = 3000,
    ) -> dict[str, object]:
        row_count = int(len(matrix))
        cluster_count = int(len(centroids))
        inertia = float(np.square(distances).sum())
        overall_mean = matrix.mean(axis=0)

        counts = np.bincount(labels, minlength=cluster_count).astype(float)
        between = float(
            sum(
                counts[cluster] * np.square(centroids[cluster] - overall_mean).sum()
                for cluster in range(cluster_count)
                if counts[cluster] > 0
            )
        )
        if cluster_count > 1 and row_count > cluster_count and inertia > 0:
            calinski_harabasz = (between / (cluster_count - 1)) / (inertia / (row_count - cluster_count))
        else:
            calinski_harabasz = 0.0

        scatter = np.zeros(cluster_count, dtype=float)
        for cluster in range(cluster_count):
            mask = labels == cluster
            scatter[cluster] = float(distances[mask].mean()) if mask.any() else 0.0

        centroid_distances = np.sqrt(((centroids[:, None, :] - centroids[None, :, :]) ** 2).sum(axis=2))
        db_values = []
        for cluster in range(cluster_count):
            ratios = []
            for other in range(cluster_count):
                if cluster == other:
                    continue
                separation = centroid_distances[cluster, other]
                if separation > 0:
                    ratios.append((scatter[cluster] + scatter[other]) / separation)
            db_values.append(max(ratios) if ratios else 0.0)
        davies_bouldin = float(np.mean(db_values)) if db_values else 0.0
        silhouette, silhouette_rows = NVIDIAAssortmentClusterModel._silhouette_sample(
            matrix,
            labels,
            sample_size=silhouette_sample_size,
            random_state=random_state,
        )

        return {
            "inertia": round(inertia, 4),
            "calinski_harabasz_score": round(float(calinski_harabasz), 4),
            "davies_bouldin_index": round(float(davies_bouldin), 4),
            "silhouette_score_sample": silhouette,
            "silhouette_sample_rows": silhouette_rows,
        }

    @staticmethod
    def _normalize_metric(values: list[float], higher_is_better: bool) -> list[float]:
        arr = np.asarray(values, dtype=float)
        if len(arr) == 0 or float(arr.max()) == float(arr.min()):
            return [0.5 for _ in values]
        normalized = (arr - arr.min()) / (arr.max() - arr.min())
        if not higher_is_better:
            normalized = 1 - normalized
        return [float(value) for value in normalized]

    def _evaluate_k_candidates(self, features: pd.DataFrame, matrix: np.ndarray) -> list[dict[str, object]]:
        sample_idx = self._sample_indices(len(matrix), sample_size=45000, random_state=self.random_state + 17)
        sample_features = features.iloc[sample_idx].reset_index(drop=True)
        sample_matrix = matrix[sample_idx]
        rows: list[dict[str, object]] = []

        for candidate_k in range(3, 10):
            centroids = self._initial_centroids(sample_features, sample_matrix, n_clusters=candidate_k)
            labels, distances, centroids, iterations = self._fit_kmeans(
                sample_matrix,
                centroids,
                n_clusters=candidate_k,
            )
            metrics = self._validation_metrics(
                sample_matrix,
                labels,
                centroids,
                distances,
                random_state=self.random_state + candidate_k,
                silhouette_sample_size=1800,
            )
            rows.append(
                {
                    "k": int(candidate_k),
                    "selected": candidate_k == self.n_clusters,
                    "sample_rows": int(len(sample_matrix)),
                    "iterations": int(iterations),
                    **metrics,
                }
            )

        inertia_scores = self._normalize_metric([float(row["inertia"]) for row in rows], higher_is_better=False)
        silhouette_scores = self._normalize_metric(
            [float(row["silhouette_score_sample"]) for row in rows],
            higher_is_better=True,
        )
        db_scores = self._normalize_metric(
            [float(row["davies_bouldin_index"]) for row in rows],
            higher_is_better=False,
        )
        ch_scores = self._normalize_metric(
            [float(row["calinski_harabasz_score"]) for row in rows],
            higher_is_better=True,
        )

        for row, inertia_score, silhouette_score, db_score, ch_score in zip(
            rows,
            inertia_scores,
            silhouette_scores,
            db_scores,
            ch_scores,
        ):
            row["selection_score"] = round(
                float(0.35 * silhouette_score + 0.30 * db_score + 0.20 * ch_score + 0.15 * inertia_score),
                4,
            )

        return rows

    @staticmethod
    def _pick_clusters(stats: pd.DataFrame, ascending: bool, target_share: float) -> set[int]:
        selected: set[int] = set()
        running_share = 0.0
        ordered = stats.sort_values("model_value", ascending=ascending)

        for row in ordered.itertuples(index=False):
            if selected and running_share >= target_share:
                break
            selected.add(int(row.model_cluster))
            running_share += float(row.population_share)

        return selected

    def _cluster_actions(self, frame: pd.DataFrame, labels: np.ndarray) -> tuple[pd.DataFrame, dict[int, str]]:
        clustered = frame.assign(model_cluster=labels)
        stats = (
            clustered.groupby("model_cluster", as_index=False)
            .agg(
                rows=("product_id", "size"),
                demand_score=("demand_score", "mean"),
                trend_score=("trend_score", "mean"),
                reorder_rate=("reorder_rate", "mean"),
                velocity_rank=("velocity_rank", "mean"),
                region_fit_score=("region_fit_score", "mean"),
                local_preference_score=("local_preference_score", "mean"),
                supplier_score=("supplier_score", "mean"),
                fill_rate=("fill_rate", "mean"),
                lead_time_days=("lead_time_days", "mean"),
                stock_cover_days=("stock_cover_days", "mean"),
            )
        )
        stats["population_share"] = stats["rows"] / max(len(frame), 1)
        stats["lead_time_score"] = 1 - np.clip((stats["lead_time_days"] - 2) / 19, 0, 1)
        stats["stock_cover_score"] = np.clip(stats["stock_cover_days"] / 28, 0, 1)
        stats["model_value"] = (
            0.22 * stats["demand_score"]
            + 0.16 * stats["velocity_rank"]
            + 0.13 * stats["trend_score"]
            + 0.12 * stats["region_fit_score"]
            + 0.10 * stats["reorder_rate"]
            + 0.09 * stats["supplier_score"]
            + 0.07 * stats["fill_rate"]
            + 0.05 * stats["local_preference_score"]
            + 0.04 * stats["lead_time_score"]
            + 0.02 * stats["stock_cover_score"]
        )

        add_clusters = self._pick_clusters(stats, ascending=False, target_share=self.add_share)
        remove_clusters = self._pick_clusters(stats, ascending=True, target_share=self.remove_share)
        action_by_cluster = {
            int(cluster): "ADD" if int(cluster) in add_clusters else "REMOVE" if int(cluster) in remove_clusters else "RETAIN"
            for cluster in stats["model_cluster"]
        }
        stats["action"] = stats["model_cluster"].map(action_by_cluster)
        return stats, action_by_cluster

    def predict(self, frame: pd.DataFrame) -> pd.DataFrame:
        features, matrix = self._feature_matrix(frame)
        centroids = self._initial_centroids(features, matrix)
        labels, distances, centroids, iterations = self._fit_kmeans(matrix, centroids)
        stats, action_by_cluster = self._cluster_actions(frame, labels)
        validation_metrics = self._validation_metrics(
            matrix,
            labels,
            centroids,
            distances,
            random_state=self.random_state,
        )
        k_selection = self._evaluate_k_candidates(features, matrix)

        value_by_cluster = stats.set_index("model_cluster")["model_value"]
        score_by_cluster = minmax(value_by_cluster).to_dict()
        median_distance_by_cluster = pd.Series(distances).groupby(labels).median().replace(0, 1.0).to_dict()
        cluster_distance_scale = np.array([median_distance_by_cluster.get(int(label), 1.0) for label in labels])
        cluster_proximity = 1 - np.clip(distances / (3.0 * cluster_distance_scale), 0, 1) * 0.5
        cluster_score = np.array([score_by_cluster.get(int(label), 0.5) for label in labels])
        action_support = np.clip(0.55 + 0.25 * cluster_proximity + 0.20 * np.abs(cluster_score - 0.5) * 2, 0, 1)

        result = frame.copy()
        result["model_cluster"] = labels.astype(int)
        result["action"] = result["model_cluster"].map(action_by_cluster)
        result["cluster_proximity_score"] = np.round(cluster_proximity, 4)
        result["action_support_score"] = np.round(action_support, 4)
        result["assortment_score"] = np.round(np.clip(0.86 * cluster_score + 0.14 * cluster_proximity, 0, 1), 4)

        stats = stats.sort_values("model_value", ascending=False).reset_index(drop=True)
        average_cluster_proximity = round(float(result["cluster_proximity_score"].mean()), 4)
        self.summary_ = {
            "model_name": "GPU-compatible K-Means Assortment Model",
            "model_family": "Unsupervised K-Means clustering",
            "runtime": "Local NumPy CPU; feature matrix can be migrated to RAPIDS cuML for NVIDIA GPU acceleration",
            "uses_rule_based_action_logic": False,
            "action_mapping_method": (
                "K-Means clusters are ranked after training by a composite business-value score. "
                "Highest-value clusters are assigned ADD, lowest-value clusters are assigned REMOVE, "
                "and middle clusters are assigned RETAIN."
            ),
            "business_value_formula": (
                "0.22*demand_score + 0.16*velocity_rank + 0.13*trend_score + "
                "0.12*region_fit_score + 0.10*reorder_rate + 0.09*supplier_score + "
                "0.07*fill_rate + 0.05*local_preference_score + 0.04*lead_time_score + "
                "0.02*stock_cover_score"
            ),
            "cluster_proximity_note": (
                "cluster_proximity_score is a normalized distance-to-centroid score. "
                "It is not supervised prediction accuracy and is not a calibrated probability."
            ),
            "k_selection_note": (
                "Candidate K values from 3 to 9 are reported with internal clustering metrics. "
                "K=3 is selected because it gives the strongest combined validation score in this run "
                "and maps naturally to high, middle, and low business-value bands for ADD, RETAIN, "
                "and REMOVE review."
            ),
            "features": MODEL_FEATURES,
            "rows_fit": int(len(result)),
            "clusters": int(self.n_clusters),
            "iterations": int(iterations),
            "inertia": validation_metrics["inertia"],
            "validation_metrics": validation_metrics,
            "k_selection": k_selection,
            "average_cluster_proximity_score": average_cluster_proximity,
            "action_counts": {key: int(value) for key, value in result["action"].value_counts().to_dict().items()},
            "cluster_summary": [
                {
                    "model_cluster": int(row.model_cluster),
                    "action": str(row.action),
                    "rows": int(row.rows),
                    "population_share": round(float(row.population_share), 4),
                    "model_value": round(float(row.model_value), 4),
                    "demand_score": round(float(row.demand_score), 4),
                    "trend_score": round(float(row.trend_score), 4),
                    "supplier_score": round(float(row.supplier_score), 4),
                    "region_fit_score": round(float(row.region_fit_score), 4),
                }
                for row in stats.itertuples(index=False)
            ],
        }
        return result


def build_supplier_table(product_metrics: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []

    for record in product_metrics.itertuples(index=False):
        product_id = int(record.product_id)
        department = str(record.department)
        role = department_role(department)

        if role == "Fresh":
            template_choices = (SUPPLIER_TEMPLATES[0], SUPPLIER_TEMPLATES[3], SUPPLIER_TEMPLATES[4])
        elif role == "Pantry":
            template_choices = (SUPPLIER_TEMPLATES[1], SUPPLIER_TEMPLATES[2], SUPPLIER_TEMPLATES[3])
        elif role == "Care":
            template_choices = (SUPPLIER_TEMPLATES[2], SUPPLIER_TEMPLATES[4], SUPPLIER_TEMPLATES[5])
        else:
            template_choices = (SUPPLIER_TEMPLATES[1], SUPPLIER_TEMPLATES[3], SUPPLIER_TEMPLATES[5])

        pick = int(stable_fraction(product_id, department, "supplier") * len(template_choices))
        supplier = template_choices[min(pick, len(template_choices) - 1)]

        fill_noise = (stable_fraction(product_id, "fill") - 0.5) * 0.16
        fill_rate = float(np.clip(supplier.fill_base + fill_noise, 0.58, 0.99))

        lead_noise = int(round((stable_fraction(product_id, "lead") - 0.5) * 8))
        lead_time_days = int(np.clip(supplier.lead_base + lead_noise, 2, 21))

        weekly_units = 3 + 90 * float(record.demand_score)
        stock_factor = 0.35 + 3.2 * stable_fraction(product_id, "stock")
        current_stock = int(max(0, round(weekly_units * stock_factor)))
        stock_cover_days = float(current_stock / max(weekly_units / 7.0, 0.1))

        min_order_qty = int(12 + 108 * stable_fraction(product_id, "moq"))
        lead_score = 1 - ((lead_time_days - 2) / 19)
        cover_score = float(np.clip(stock_cover_days / 28, 0, 1))
        supplier_score = float(np.clip(0.52 * fill_rate + 0.25 * lead_score + 0.23 * cover_score, 0, 1))

        if fill_rate >= 0.86 and lead_time_days <= 8 and stock_cover_days >= 14:
            status = "Ready"
        elif fill_rate >= 0.74 and stock_cover_days >= 7:
            status = "Watch"
        else:
            status = "Risk"

        rows.append(
            {
                "product_id": product_id,
                "supplier_name": supplier.name,
                "supplier_tier": supplier.tier,
                "fill_rate": round(fill_rate, 4),
                "lead_time_days": lead_time_days,
                "current_stock": current_stock,
                "stock_cover_days": round(stock_cover_days, 2),
                "min_order_qty": min_order_qty,
                "supplier_score": round(supplier_score, 4),
                "supplier_status": status,
            }
        )

    return pd.DataFrame(rows)


def _role_region_bonus(role: str, profile: pd.Series) -> float:
    traffic = float(profile["traffic_index"])
    promo = float(profile["promo_index"])
    basket = float(profile["basket_index"])
    growth = float(profile["growth_index"])

    if role == "Fresh":
        return 0.18 * traffic + 0.10 * growth + 0.04 * basket
    if role == "Pantry":
        return 0.15 * promo + 0.10 * traffic + 0.06 * growth
    if role == "Care":
        return 0.14 * basket + 0.10 * growth + 0.05 * promo
    return 0.10 * basket + 0.10 * traffic + 0.08 * growth


def replenishment_priority(row: pd.Series) -> str:
    if row["movement_class"] == "Fast-moving" and row["stock_cover_days"] < 10:
        return "Urgent replenish"
    if row["supplier_status"] == "Risk" and row["lead_time_days"] >= 12:
        return "Supplier backup needed"
    if row["movement_class"] == "Slow-moving" and row["stock_cover_days"] > 20:
        return "Reduce next buy"
    return "Normal"


def explain_recommendation(row: pd.Series) -> str:
    product = row["product_name"]
    region = row["region"]
    action = row["action"].lower()
    movement = row["movement_class"].lower()
    trend = "rising" if row["trend_index"] >= 1.05 else "softening" if row["trend_index"] < 0.9 else "stable"
    supplier = row["supplier_status"].lower()
    score = int(round(row["assortment_score"] * 100))
    cluster = int(row.get("model_cluster", 0))
    proximity = float(row.get("cluster_proximity_score", 0))

    if row["action"] == "ADD":
        opener = f"Add or expand {product} in {region}"
    elif row["action"] == "REMOVE":
        opener = f"Reduce or remove {product} in {region}"
    else:
        opener = f"Retain {product} in {region}"

    return (
        f"{opener}: ML cluster {cluster} grouped this as a {movement} SKU with {trend} demand, "
        f"{supplier} supplier status, {row['fill_rate']:.0%} fill rate, {row['lead_time_days']} day lead time, "
        f"{score}/100 model score, and {proximity:.0%} cluster proximity. Recommended action: {action}."
    )


def make_recommendations(
    product_metrics: pd.DataFrame,
    supplier_status: pd.DataFrame,
    region_profiles: pd.DataFrame,
) -> pd.DataFrame:
    base = product_metrics.merge(supplier_status, on="product_id", how="left")
    base["department_role"] = base["department"].map(department_role)

    regional_frames: list[pd.DataFrame] = []
    for profile in region_profiles.itertuples(index=False):
        profile_series = pd.Series(profile._asdict())
        region = str(profile_series["region"])
        frame = base.copy()
        frame["region"] = region
        frame["region_strength"] = float(profile_series["region_strength"])
        frame["local_preference_score"] = frame["department_role"].map(
            lambda role: float(np.clip(0.48 + _role_region_bonus(role, profile_series), 0, 1))
        )
        frame["region_fit_score"] = np.clip(
            0.58 * frame["demand_score"]
            + 0.24 * frame["local_preference_score"]
            + 0.18 * float(profile_series["region_strength"]),
            0,
            1,
        )
        regional_frames.append(frame)

    recommendations = pd.concat(regional_frames, ignore_index=True)
    model = NVIDIAAssortmentClusterModel()
    recommendations = model.predict(recommendations)
    recommendations["replenishment_priority"] = recommendations.apply(replenishment_priority, axis=1)
    recommendations["explanation"] = recommendations.apply(explain_recommendation, axis=1)

    preferred_columns = [
        "region",
        "product_id",
        "product_name",
        "department",
        "aisle",
        "department_role",
        "action",
        "movement_class",
        "replenishment_priority",
        "assortment_score",
        "demand_score",
        "trend_index",
        "reorder_rate",
        "units_total",
        "units_prior",
        "units_train",
        "region_fit_score",
        "local_preference_score",
        "supplier_name",
        "supplier_status",
        "supplier_score",
        "fill_rate",
        "lead_time_days",
        "current_stock",
        "stock_cover_days",
        "min_order_qty",
        "model_cluster",
        "cluster_proximity_score",
        "action_support_score",
        "explanation",
    ]
    recommendations = recommendations[preferred_columns].sort_values(
        ["action", "assortment_score", "units_total"],
        ascending=[True, False, False],
    )
    model.summary_["action_counts"] = {
        key: int(value) for key, value in recommendations["action"].value_counts().to_dict().items()
    }
    recommendations.attrs["model_summary"] = model.summary_
    return recommendations


def category_summary(recommendations: pd.DataFrame) -> pd.DataFrame:
    grouped = (
        recommendations.groupby(["region", "department"], as_index=False)
        .agg(
            products=("product_id", "nunique"),
            avg_assortment_score=("assortment_score", "mean"),
            add_count=("action", lambda values: int((values == "ADD").sum())),
            retain_count=("action", lambda values: int((values == "RETAIN").sum())),
            remove_count=("action", lambda values: int((values == "REMOVE").sum())),
            fast_movers=("movement_class", lambda values: int((values == "Fast-moving").sum())),
            supplier_risks=("supplier_status", lambda values: int((values == "Risk").sum())),
        )
        .sort_values(["region", "avg_assortment_score"], ascending=[True, False])
    )
    grouped["category_change"] = np.select(
        [
            grouped["add_count"] > grouped["remove_count"] * 1.3,
            grouped["remove_count"] > grouped["add_count"] * 1.3,
        ],
        ["Expand", "Rationalize"],
        default="Maintain",
    )
    grouped["avg_assortment_score"] = grouped["avg_assortment_score"].round(4)
    return grouped


def build_manager_briefs(category_table: pd.DataFrame, region_profiles: pd.DataFrame) -> list[dict[str, str]]:
    briefs: list[dict[str, str]] = []
    for profile in region_profiles.itertuples(index=False):
        region = profile.region
        region_categories = category_table[category_table["region"] == region]
        expand = region_categories.sort_values(["add_count", "avg_assortment_score"], ascending=False).head(3)
        reduce = region_categories.sort_values(["remove_count", "supplier_risks"], ascending=False).head(3)

        expand_names = ", ".join(expand["department"].tolist()) or "core categories"
        reduce_names = ", ".join(reduce["department"].tolist()) or "low-signal categories"

        briefs.append(
            {
                "region": region,
                "headline": f"{region}: prioritize {expand_names}",
                "brief": (
                    f"{region} shows a region strength index of {profile.region_strength:.2f}. "
                    f"Expand {expand_names} where demand and local fit are strongest. "
                    f"Rationalize {reduce_names} where demand is weaker or supplier risk is elevated."
                ),
            }
        )
    return briefs


def select_dashboard_records(recommendations: pd.DataFrame, per_bucket: int = 350) -> pd.DataFrame:
    buckets: Iterable[pd.DataFrame] = (
        recommendations[recommendations["action"] == "ADD"].nlargest(per_bucket, "assortment_score"),
        recommendations[recommendations["action"] == "REMOVE"].nsmallest(per_bucket, "assortment_score"),
        recommendations[recommendations["movement_class"] == "Fast-moving"].nlargest(per_bucket, "units_total"),
        recommendations[recommendations["supplier_status"] == "Risk"].nlargest(per_bucket, "demand_score"),
        recommendations[recommendations["action"] == "RETAIN"].nlargest(per_bucket, "assortment_score"),
    )
    selected = pd.concat(list(buckets), ignore_index=True)
    selected = selected.drop_duplicates(["region", "product_id"]).sort_values(
        ["assortment_score", "units_total"], ascending=False
    )
    return selected.head(per_bucket * 5)
