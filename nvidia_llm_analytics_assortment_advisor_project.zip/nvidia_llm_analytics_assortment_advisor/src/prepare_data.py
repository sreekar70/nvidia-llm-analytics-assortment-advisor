"""Prepare analytics outputs for the Assortment Advisor dashboard."""

from __future__ import annotations

import argparse
import json
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

from advisor_engine import (
    REGION_NAMES,
    assign_region,
    build_manager_briefs,
    build_supplier_table,
    category_summary,
    make_recommendations,
    minmax,
    movement_label,
    select_dashboard_records,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INSTACART_REQUIRED = {
    "aisles.csv",
    "departments.csv",
    "order_products__prior.csv",
    "order_products__train.csv",
    "products.csv",
}
ROSSMANN_REQUIRED = {"store.csv", "train.csv"}


def zip_members(zip_path: Path) -> set[str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {Path(name).name for name in archive.namelist()}


def locate_zip(source_dir: Path, required_members: set[str], label: str) -> Path:
    candidates = sorted(source_dir.glob("*.zip"))
    for candidate in candidates:
        try:
            if required_members.issubset(zip_members(candidate)):
                return candidate
        except zipfile.BadZipFile:
            continue
    expected = ", ".join(sorted(required_members))
    raise FileNotFoundError(f"Could not find {label} zip in {source_dir}. Expected members: {expected}")


def locate_source_dir(user_source: str | None) -> Path:
    candidates: list[Path] = []
    if user_source:
        candidates.append(Path(user_source))
    candidates.extend(
        [
            PROJECT_ROOT / "data" / "raw",
            PROJECT_ROOT.parent.parent / "work" / "source_files",
            Path.cwd() / "work" / "source_files",
        ]
    )

    for candidate in candidates:
        if candidate.exists() and any(candidate.glob("*.zip")):
            return candidate.resolve()
    raise FileNotFoundError("No source zip files found. Put the archives in data/raw or pass --source-dir.")


def read_csv_from_zip(zip_path: Path, member_name: str, **kwargs) -> pd.DataFrame:
    with zipfile.ZipFile(zip_path) as archive:
        match = next((name for name in archive.namelist() if Path(name).name == member_name), None)
        if match is None:
            raise FileNotFoundError(f"{member_name} not found in {zip_path}")
        with archive.open(match) as handle:
            return pd.read_csv(handle, **kwargs)


def aggregate_order_products(
    zip_path: Path,
    member_name: str,
    chunk_size: int,
    max_rows: int | None = None,
) -> pd.DataFrame:
    accumulator: pd.DataFrame | None = None
    consumed = 0

    with zipfile.ZipFile(zip_path) as archive:
        match = next((name for name in archive.namelist() if Path(name).name == member_name), None)
        if match is None:
            raise FileNotFoundError(f"{member_name} not found in {zip_path}")

        with archive.open(match) as handle:
            reader = pd.read_csv(
                handle,
                usecols=["product_id", "add_to_cart_order", "reordered"],
                dtype={"product_id": "int32", "add_to_cart_order": "int16", "reordered": "int8"},
                chunksize=chunk_size,
            )
            for chunk in reader:
                if max_rows is not None:
                    remaining = max_rows - consumed
                    if remaining <= 0:
                        break
                    if len(chunk) > remaining:
                        chunk = chunk.iloc[:remaining].copy()

                grouped = chunk.groupby("product_id").agg(
                    units=("product_id", "size"),
                    reorders=("reordered", "sum"),
                    cart_order_sum=("add_to_cart_order", "sum"),
                )
                accumulator = grouped if accumulator is None else accumulator.add(grouped, fill_value=0)
                consumed += len(chunk)

    if accumulator is None:
        return pd.DataFrame(columns=["product_id", "units", "reorders", "cart_order_sum"])

    return accumulator.reset_index()


def build_product_metrics(instacart_zip: Path, chunk_size: int, max_rows: int | None) -> pd.DataFrame:
    products = read_csv_from_zip(instacart_zip, "products.csv")
    aisles = read_csv_from_zip(instacart_zip, "aisles.csv")
    departments = read_csv_from_zip(instacart_zip, "departments.csv")

    prior = aggregate_order_products(instacart_zip, "order_products__prior.csv", chunk_size, max_rows)
    train = aggregate_order_products(instacart_zip, "order_products__train.csv", chunk_size, max_rows)

    prior = prior.rename(
        columns={
            "units": "units_prior",
            "reorders": "reorders_prior",
            "cart_order_sum": "cart_order_sum_prior",
        }
    )
    train = train.rename(
        columns={
            "units": "units_train",
            "reorders": "reorders_train",
            "cart_order_sum": "cart_order_sum_train",
        }
    )

    metrics = (
        products.merge(aisles, on="aisle_id", how="left")
        .merge(departments, on="department_id", how="left")
        .merge(prior, on="product_id", how="left")
        .merge(train, on="product_id", how="left")
    )

    numeric_cols = [
        "units_prior",
        "reorders_prior",
        "cart_order_sum_prior",
        "units_train",
        "reorders_train",
        "cart_order_sum_train",
    ]
    metrics[numeric_cols] = metrics[numeric_cols].fillna(0)
    metrics["units_total"] = metrics["units_prior"] + metrics["units_train"]
    metrics["reorders_total"] = metrics["reorders_prior"] + metrics["reorders_train"]
    metrics["cart_order_sum_total"] = metrics["cart_order_sum_prior"] + metrics["cart_order_sum_train"]

    metrics["reorder_rate"] = np.where(
        metrics["units_total"] > 0,
        metrics["reorders_total"] / metrics["units_total"],
        0,
    )
    metrics["avg_add_to_cart_order"] = np.where(
        metrics["units_total"] > 0,
        metrics["cart_order_sum_total"] / metrics["units_total"],
        np.nan,
    )
    metrics["avg_add_to_cart_order"] = metrics["avg_add_to_cart_order"].fillna(
        metrics["avg_add_to_cart_order"].median()
    )

    product_count = max(len(metrics), 1)
    prior_total = max(float(metrics["units_prior"].sum()), 1.0)
    train_total = max(float(metrics["units_train"].sum()), 1.0)
    prior_share = (metrics["units_prior"] + 0.5) / (prior_total + 0.5 * product_count)
    train_share = (metrics["units_train"] + 0.5) / (train_total + 0.5 * product_count)
    metrics["trend_index"] = (train_share / prior_share).clip(0, 3.0)

    metrics["unit_score"] = minmax(np.log1p(metrics["units_total"]))
    metrics["trend_score"] = minmax(metrics["trend_index"], floor=0.55, cap=1.75)
    metrics["cart_priority_score"] = 1 - minmax(metrics["avg_add_to_cart_order"], floor=1, cap=35)
    metrics["demand_score"] = (
        0.52 * metrics["unit_score"]
        + 0.24 * metrics["reorder_rate"].clip(0, 1)
        + 0.14 * metrics["cart_priority_score"]
        + 0.10 * metrics["trend_score"]
    ).clip(0, 1)
    metrics["velocity_rank"] = metrics["demand_score"].rank(method="average", pct=True)
    metrics["movement_class"] = metrics.apply(movement_label, axis=1)

    keep = [
        "product_id",
        "product_name",
        "aisle",
        "department",
        "units_prior",
        "units_train",
        "units_total",
        "reorders_total",
        "reorder_rate",
        "avg_add_to_cart_order",
        "trend_index",
        "trend_score",
        "unit_score",
        "cart_priority_score",
        "demand_score",
        "velocity_rank",
        "movement_class",
    ]
    metrics = metrics[keep].sort_values("demand_score", ascending=False)

    rounded = ["reorder_rate", "avg_add_to_cart_order", "trend_index", "trend_score", "unit_score", "cart_priority_score", "demand_score", "velocity_rank"]
    metrics[rounded] = metrics[rounded].round(4)
    return metrics


def build_region_profiles(rossmann_zip: Path) -> pd.DataFrame:
    stores = read_csv_from_zip(rossmann_zip, "store.csv")
    train = read_csv_from_zip(rossmann_zip, "train.csv", parse_dates=["Date"])

    data = train.merge(stores, on="Store", how="left")
    data["Open"] = data["Open"].fillna(1)
    data = data[(data["Open"] == 1) & (data["Sales"] > 0) & (data["Customers"] > 0)].copy()
    data["region"] = data["Store"].map(assign_region)
    data["basket_value"] = data["Sales"] / data["Customers"].replace(0, np.nan)

    recent_cutoff = data["Date"].max() - pd.Timedelta(days=120)
    base = data.groupby("region", as_index=False).agg(
        stores=("Store", "nunique"),
        avg_daily_sales=("Sales", "mean"),
        avg_customers=("Customers", "mean"),
        avg_basket_value=("basket_value", "mean"),
        promo_days=("Promo", "sum"),
    )

    promo = data.groupby(["region", "Promo"])["Sales"].mean().unstack(fill_value=np.nan)
    promo_lift = ((promo.get(1, promo.mean(axis=1)) - promo.get(0, promo.mean(axis=1))) / promo.get(0, promo.mean(axis=1))).fillna(0)
    promo_lift = promo_lift.rename("promo_lift").reset_index()

    recent = data[data["Date"] >= recent_cutoff].groupby("region")["Sales"].mean()
    historical = data[data["Date"] < recent_cutoff].groupby("region")["Sales"].mean()
    growth = ((recent - historical) / historical).replace([np.inf, -np.inf], np.nan).fillna(0)
    growth = growth.rename("recent_growth").reset_index()

    profiles = base.merge(promo_lift, on="region", how="left").merge(growth, on="region", how="left")
    profiles["traffic_index"] = minmax(profiles["avg_customers"])
    profiles["promo_index"] = minmax(profiles["promo_lift"], floor=-0.05, cap=0.45)
    profiles["basket_index"] = minmax(profiles["avg_basket_value"])
    profiles["growth_index"] = minmax(profiles["recent_growth"], floor=-0.25, cap=0.35)
    profiles["region_strength"] = (
        0.33 * profiles["traffic_index"]
        + 0.24 * profiles["promo_index"]
        + 0.22 * profiles["basket_index"]
        + 0.21 * profiles["growth_index"]
    ).clip(0, 1)

    ordered_regions = list(dict.fromkeys(REGION_NAMES.values()))
    profiles["region"] = pd.Categorical(profiles["region"], categories=ordered_regions, ordered=True)
    profiles = profiles.sort_values("region").reset_index(drop=True)
    profiles["region"] = profiles["region"].astype(str)

    round_cols = [
        "avg_daily_sales",
        "avg_customers",
        "avg_basket_value",
        "promo_lift",
        "recent_growth",
        "traffic_index",
        "promo_index",
        "basket_index",
        "growth_index",
        "region_strength",
    ]
    profiles[round_cols] = profiles[round_cols].round(4)
    profiles["profile_type"] = "Synthetic analytical profile derived from Rossmann store signals"
    return profiles


def json_records(frame: pd.DataFrame, columns: list[str] | None = None, max_rows: int | None = None) -> list[dict]:
    data = frame.copy()
    if columns:
        data = data[columns]
    if max_rows:
        data = data.head(max_rows)
    return json.loads(data.to_json(orient="records"))


def build_dashboard_payload(
    product_metrics: pd.DataFrame,
    supplier_status: pd.DataFrame,
    recommendations: pd.DataFrame,
    categories: pd.DataFrame,
    regions: pd.DataFrame,
    source_dir: Path,
    instacart_zip: Path,
    rossmann_zip: Path,
) -> dict:
    action_counts = recommendations["action"].value_counts().reindex(["ADD", "RETAIN", "REMOVE"], fill_value=0)
    movement_counts = recommendations["movement_class"].value_counts().reindex(["Fast-moving", "Steady", "Slow-moving"], fill_value=0)
    model_summary = recommendations.attrs.get("model_summary", {})

    dashboard_records = select_dashboard_records(recommendations)
    top_departments = categories.sort_values(
        ["add_count", "avg_assortment_score"], ascending=False
    ).head(30)
    supplier_risks = recommendations[
        (recommendations["supplier_status"] == "Risk") & (recommendations["demand_score"] >= recommendations["demand_score"].quantile(0.65))
    ].nlargest(25, "demand_score")

    kpis = {
        "products_analyzed": int(product_metrics["product_id"].nunique()),
        "recommendation_rows": int(len(recommendations)),
        "regions": int(regions["region"].nunique()),
        "departments": int(product_metrics["department"].nunique()),
        "add_recommendations": int(action_counts["ADD"]),
        "retain_recommendations": int(action_counts["RETAIN"]),
        "remove_recommendations": int(action_counts["REMOVE"]),
        "supplier_risk_skus": int((supplier_status["supplier_status"] == "Risk").sum()),
        "fast_moving_skus": int((product_metrics["movement_class"] == "Fast-moving").sum()),
        "slow_moving_skus": int((product_metrics["movement_class"] == "Slow-moving").sum()),
        "model_clusters": int(model_summary.get("clusters", 0)),
        "avg_cluster_proximity_score": float(model_summary.get("average_cluster_proximity_score", 0)),
    }

    return {
        "project": {
            "id": "ASSORTMENT-ADVISOR-AI",
            "title": "Assortment Advisor: AI-Powered Category Management",
            "problem_statement": "Create an assortment advisor that combines sales trends, local preferences, and supplier availability to suggest category changes.",
            "source_dir": str(source_dir),
            "instacart_archive": instacart_zip.name,
            "rossmann_archive": rossmann_zip.name,
            "data_notes": {
                "transaction_data": "Instacart order data is used as POS-style transaction-demand proxy data.",
                "regional_profiles": "Rossmann store data is converted into synthetic analytical regional profiles, not real geographic regions.",
                "supplier_data": "Supplier availability is deterministically simulated because real supplier feeds were not provided.",
            },
        },
        "model": model_summary,
        "kpis": kpis,
        "actionCounts": action_counts.astype(int).to_dict(),
        "movementCounts": movement_counts.astype(int).to_dict(),
        "regions": json_records(regions),
        "categorySummary": json_records(top_departments),
        "records": json_records(
            dashboard_records,
            columns=[
                "region",
                "product_id",
                "product_name",
                "department",
                "aisle",
                "action",
                "movement_class",
                "replenishment_priority",
                "assortment_score",
                "demand_score",
                "trend_index",
                "reorder_rate",
                "region_fit_score",
                "supplier_name",
                "supplier_status",
                "fill_rate",
                "lead_time_days",
                "stock_cover_days",
                "model_cluster",
                "cluster_proximity_score",
                "action_support_score",
                "explanation",
            ],
        ),
        "fastMovers": json_records(
            recommendations[recommendations["movement_class"] == "Fast-moving"].nlargest(25, "units_total"),
            columns=["region", "product_name", "department", "units_total", "trend_index", "supplier_status", "action"],
        ),
        "slowMovers": json_records(
            recommendations[recommendations["movement_class"] == "Slow-moving"].nsmallest(25, "assortment_score"),
            columns=["region", "product_name", "department", "units_total", "trend_index", "supplier_status", "action"],
        ),
        "supplierRisks": json_records(
            supplier_risks,
            columns=[
                "region",
                "product_name",
                "department",
                "demand_score",
                "supplier_name",
                "fill_rate",
                "lead_time_days",
                "stock_cover_days",
                "replenishment_priority",
            ],
        ),
        "advisorBriefs": build_manager_briefs(categories, regions),
    }


def write_dashboard_data(payload: dict, assets_dir: Path) -> None:
    assets_dir.mkdir(parents=True, exist_ok=True)
    target = assets_dir / "dashboard_data.js"
    target.write_text(
        "window.ASSORTMENT_DATA = "
        + json.dumps(payload, ensure_ascii=False, indent=2)
        + ";\n",
        encoding="utf-8",
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build ML assortment advisor analytics outputs.")
    parser.add_argument("--source-dir", default=None, help="Folder containing the two provided zip archives.")
    parser.add_argument("--output-dir", default=str(PROJECT_ROOT / "data" / "processed"))
    parser.add_argument("--chunk-size", type=int, default=1_500_000)
    parser.add_argument("--max-order-rows", type=int, default=None, help="Optional row cap for quick demos.")
    args = parser.parse_args(argv)

    source_dir = locate_source_dir(args.source_dir)
    instacart_zip = locate_zip(source_dir, INSTACART_REQUIRED, "Instacart Market Basket")
    rossmann_zip = locate_zip(source_dir, ROSSMANN_REQUIRED, "Rossmann Store Sales")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Using source files from: {source_dir}")
    print(f"Instacart archive: {instacart_zip.name}")
    print(f"Rossmann archive: {rossmann_zip.name}")
    print("Building product demand and trend metrics...")
    product_metrics = build_product_metrics(instacart_zip, args.chunk_size, args.max_order_rows)

    print("Building local preference profiles...")
    region_profiles = build_region_profiles(rossmann_zip)

    print("Generating supplier availability layer...")
    supplier_status = build_supplier_table(product_metrics)

    print("Training local K-Means ML model and generating assortment recommendations...")
    recommendations = make_recommendations(product_metrics, supplier_status, region_profiles)
    categories = category_summary(recommendations)
    model_summary = recommendations.attrs.get("model_summary", {})

    print("Writing processed data files...")
    product_metrics.to_csv(output_dir / "product_metrics.csv", index=False)
    supplier_status.to_csv(output_dir / "supplier_status.csv", index=False)
    recommendations.to_csv(output_dir / "assortment_recommendations.csv", index=False)
    categories.to_csv(output_dir / "category_summary.csv", index=False)
    region_profiles.to_csv(output_dir / "region_summary.csv", index=False)
    (output_dir / "model_summary.json").write_text(json.dumps(model_summary, indent=2), encoding="utf-8")
    if model_summary.get("cluster_summary"):
        pd.DataFrame(model_summary["cluster_summary"]).to_csv(output_dir / "model_clusters.csv", index=False)

    payload = build_dashboard_payload(
        product_metrics,
        supplier_status,
        recommendations,
        categories,
        region_profiles,
        source_dir,
        instacart_zip,
        rossmann_zip,
    )
    (output_dir / "kpi_summary.json").write_text(json.dumps(payload["kpis"], indent=2), encoding="utf-8")
    write_dashboard_data(payload, PROJECT_ROOT / "assets")

    print("Done.")
    print(f"Dashboard data rows: {len(payload['records'])}")
    print(f"Processed data folder: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
